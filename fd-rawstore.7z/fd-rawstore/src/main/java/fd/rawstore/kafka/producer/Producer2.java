package fd.rawstore.kafka.producer;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;

import fd.rawstore.bin.CanInfoMessage;

public class Producer2 extends Thread {

    private final String topic;
    private final Boolean isAsync;
    private final KafkaProducer<String,  byte[]> producer;
    public Producer2(String topic, Boolean isAsync) {
        Properties props = new Properties();
        //props.put("bootstrap.servers", KafkaProperties.KAFKA_SERVER_URL + ":" + KafkaProperties.KAFKA_SERVER_PORT);
        props.put("bootstrap.servers", "localhost:9092");//"172.23.8.144:9092,172.23.8.179:9092,172.23.8.59:9092"
        props.put("client.id", "DemoProducer");
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "org.apache.kafka.common.serialization.ByteArraySerializer");


        producer = new KafkaProducer<>(props);



        this.topic = topic;
        this.isAsync = isAsync;
    }

    public void run() {
        int vin = 1111;
        fd.rawstore.bin.CanInfoMessage annMsg;
        long reciveTime = System.currentTimeMillis();
        byte[] testData = {
				0x00,0x01,0x01,0x01,0x01,0x01,0x01
			};
        Map<String , Object> annomap = new HashMap();
        annomap.put("vin", String.valueOf(vin));
        annomap.put("recicvetime", reciveTime);
        CanInfoMessage bean;

		bean = new CanInfoMessage(annomap, String.valueOf(vin), reciveTime, testData);
        byte[] messagePacker = bean.toByte();


        while (true) {

            long startTime = System.currentTimeMillis();
            if (isAsync) { // Send asynchronously

            	//ProducerRecordのコンストラクタには、Topic名、Key、Valueをそれぞれ設定します
                producer.send(new ProducerRecord<>(topic,String.valueOf(vin),messagePacker),
                		      new DemoCallBack(startTime, String.valueOf(vin), messagePacker));
            } else { // Send synchronously
                try {
//                    producer.send(new ProducerRecord<>(topic,
//                    		String.valueOf(vin),
//                    		messagePacker)).get();
                    System.out.println("Async Sent message: (" + String.valueOf(vin) + ", " + messagePacker + ")");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            ++vin;
            try {
				sleep(200);
			} catch (InterruptedException e) {
				// TODO 自動生成された catch ブロック
				e.printStackTrace();
			}
        }
    }

	private void send(ProducerRecord producerRecord, DemoCallBack demoCallBack) {
		// TODO 自動生成されたメソッド・スタブ

	}
}

class DemoCallBack implements Callback {

    private final long startTime;
    private final String key;
    private final byte[] message;

    public DemoCallBack(long startTime, String key, byte[] message) {
        this.startTime = startTime;
        this.key = key;
        this.message = message;
    }

    /**
     * A callback method the user can implement to provide asynchronous handling of request completion. This method will
     * be called when the record sent to the server has been acknowledged. Exactly one of the arguments will be
     * non-null.
     *
     * @param metadata  The metadata for the record that was sent (i.e. the partition and offset). Null if an error
     *                  occurred.
     * @param exception The exception thrown during processing of this record. Null if no error occurred.
     */
    public void onCompletion(RecordMetadata metadata, Exception exception) {
        long elapsedTime = System.currentTimeMillis() - startTime;
        if (metadata != null) {
//            System.out.println(
//                "message(" + key + ", " + message + ") sent to partition(" + metadata.partition() +
//                    "), " +
//                    "offset(" + metadata.offset() + ") in " + elapsedTime + " ms");
        } else {
            exception.printStackTrace();
        }
    }
}