package fd.rawstore.function;

import java.io.IOException;
import java.text.NumberFormat;
import java.util.Iterator;
import java.util.Random;
import java.util.TreeMap;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.SequenceFile;
import org.apache.hadoop.io.SequenceFile.CompressionType;
import org.apache.hadoop.io.compress.CompressionCodec;
import org.apache.hadoop.io.compress.DefaultCodec;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.JobContext;
import org.apache.hadoop.mapreduce.RecordWriter;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.mapreduce.TaskID;
import org.apache.hadoop.mapreduce.lib.output.FileOutputCommitter;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.ReflectionUtils;

public class CustomerSequenceFileOutputFormat<K, V> extends FileOutputFormat<K, V> {

	@Override
	public RecordWriter<K, V> getRecordWriter(TaskAttemptContext context) {

		TreeMap<String, RecordWriter<K, V>> recordWriters = new TreeMap<String, RecordWriter<K, V>>();

		return new RecordWriter<K, V>() {

			@Override
			public void write(K key, V value) throws IOException, InterruptedException {

				String extensionFileName = getExtensionFilePath(key, value);

				RecordWriter<K, V> rw = recordWriters.get(extensionFileName);

				if (rw == null) {
					rw = getBaseRecordWriter(context, extensionFileName);

					recordWriters.put(extensionFileName, rw);
				}

				rw.write(key, value);
			}

			@Override
			public void close(TaskAttemptContext context) throws IOException, InterruptedException {

				Iterator<String> keys = recordWriters.keySet().iterator();

				while (keys.hasNext()) {

					RecordWriter<K, V> rw = recordWriters.get(keys.next());

					rw.close(context);
				}

				recordWriters.clear();

			}
		};
	}

	private RecordWriter<K, V> getBaseRecordWriter(TaskAttemptContext context, String extensionFileName)
			throws IOException {

		final SequenceFile.Writer out = getSequenceWriter(context, context.getMapOutputKeyClass(),
				context.getOutputValueClass(), extensionFileName);

		return new RecordWriter<K, V>() {

			public void write(K key, V value) throws IOException {
				out.append(NullWritable.get(), value);
			}

			public void close(TaskAttemptContext context) throws IOException {
				out.close();
			}

		};
	}

	private SequenceFile.Writer getSequenceWriter(TaskAttemptContext context, Class<?> keyClass, Class<?> valueClass,
			String extensionFileName) throws IOException {

		Configuration conf = context.getConfiguration();

		CompressionCodec codec = null;

		CompressionType compressionType = CompressionType.NONE;

		if (getCompressOutput(context)) {

			compressionType = getOutputCompressionType(context);

			Class<?> codecClass = getOutputCompressorClass(context, DefaultCodec.class);

			codec = (CompressionCodec) ReflectionUtils.newInstance(codecClass, conf);

		}

		Path file = getDefaultWorkFile(context, extensionFileName);

		FileSystem fs = file.getFileSystem(conf);

		return SequenceFile.createWriter(fs, conf, file, NullWritable.class, valueClass, compressionType, codec,
				context);

	}

	@Override
	public Path getDefaultWorkFile(TaskAttemptContext context, String extension) throws IOException {
		FileOutputCommitter committer = (FileOutputCommitter) getOutputCommitter(context);
		return new Path(committer.getWorkPath(), getUniqueFile(context, getOutputName(context), extension));
	}

	private static final NumberFormat NUMBER_FORMAT = NumberFormat.getInstance();
	protected static final String BASE_OUTPUT_NAME = "mapreduce.output.basename";
	protected static final String PART = "part";
	static {
		NUMBER_FORMAT.setMinimumIntegerDigits(5);
		NUMBER_FORMAT.setGroupingUsed(false);
	}

	public synchronized static String getUniqueFile(TaskAttemptContext context, String name, String extension) {
		TaskID taskId = context.getTaskAttemptID().getTaskID();
		int partition = taskId.getId();
		StringBuilder result = new StringBuilder();

		// TaskID.getRepresentingCharacter(taskId.getTaskType());

		result.append(NUMBER_FORMAT.format(partition));

		result.append("/");

		result.append(name);
		result.append('-');

		result.append('-');
		System.out.println(NUMBER_FORMAT.format(partition));

		result.append("-aaaaaaaaa-");
		result.append(extension);
		return result.toString();
	}

	public static CompressionType getOutputCompressionType(JobContext job) {
		String val = job.getConfiguration().get(FileOutputFormat.COMPRESS_TYPE, CompressionType.RECORD.toString());
		return CompressionType.valueOf(val);
	}

	public static void setOutputCompressionType(Job job, CompressionType style) {
		setCompressOutput(job, true);
		job.getConfiguration().set(FileOutputFormat.COMPRESS_TYPE, style.toString());
	}

	private String getExtensionFilePath(K key, V value) {

		return "aaa";
	}

}
