package fd.rawstore.function;

import java.nio.charset.StandardCharsets;

import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.spark.api.java.function.PairFunction;
import org.spark_project.guava.primitives.Bytes;

import fd.rawstore.bin.CanDataAnnotatedBean;
import scala.Tuple2;

public class TranstormParquetToPairFormat
		implements PairFunction<CanDataAnnotatedBean, NullWritable, CanDataAnnotatedBean> {
	private static final long serialVersionUID = -1;

	@Override
	public Tuple2<NullWritable, CanDataAnnotatedBean> call(CanDataAnnotatedBean t) throws Exception {
		return new Tuple2<NullWritable, CanDataAnnotatedBean>(NullWritable.get(), t);
	}

}
