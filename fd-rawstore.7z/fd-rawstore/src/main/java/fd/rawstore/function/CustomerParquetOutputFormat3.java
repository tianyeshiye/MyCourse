package fd.rawstore.function;

import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.mapreduce.Job;
import org.apache.parquet.example.data.Group;
import org.apache.parquet.hadoop.ParquetOutputFormat;
import org.apache.parquet.hadoop.example.GroupWriteSupport;
import org.apache.parquet.schema.MessageType;
import org.apache.parquet.schema.OriginalType;
import org.apache.parquet.schema.PrimitiveType;
import org.apache.parquet.schema.Type;

import fd.rawstore.bin.CanDataAnnotatedBean;

import org.apache.parquet.hadoop.util.ContextUtil;

public class CustomerParquetOutputFormat3<Void, CanDataAnnotatedBean> extends ParquetOutputFormat<CanDataAnnotatedBean> {

	// AvroParquetOutputFormat
	// AvroWriteSupport
	
	public static void setSchema(Job job) {
		CustomerWriteSupport.setSchema(getSchema(), ContextUtil.getConfiguration(job));
	}

	public CustomerParquetOutputFormat3() {
		super(new CustomerWriteSupport());
	}
	
	private static MessageType getSchema() {

		List<Type> types = new ArrayList<Type>();
		Type type = null;

		type = new PrimitiveType(Type.Repetition.OPTIONAL, PrimitiveType.PrimitiveTypeName.BINARY, "vin",
				OriginalType.UTF8);
		types.add(type);
		
		return new MessageType("Ec-schema", types);

	}
}
